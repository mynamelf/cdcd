<?php
namespace Admin\Controller;
use Think\Controller;
class LYController extends Controller {
    public function y(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', '{:U("Log/log")}',3);
            return;
        }
        $date=M('ly')->select();
        $this->assign('date',$date);
        $this->display('ly');
    }


}