<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends Controller {
    public function a(){
        $user=I('post.name');
        $password=I('post.password');
        //$this->success('登录成功！', U('Admin/admin'),3);
        if(empty($user) || empty($password)){
            $this->assign('m',"账号或密码不能为空！");
            $this->display(T('Log/log'));
        }else{
            $where="per_user='".$user."'";  
            // $where.="and per_password='".md5($password)."'";  
            $where.=" and per_password='".$password."'";  
            $data=M('us')->where($where)->select();  
            if(!empty($data)){
                session('per_id',$data[0]['id']);
                session('per_name',$data[0]['per_name']);
                $this->success('登录成功！', U('Admin/admin'),3);
            }else{
                $this->assign('m',"账号或密码错误！");
                $this->display(T('Log/log'));
            }
            
        }
    }

    public function admin(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $date=M('us')->select();
        $this->assign('date',$date);
        $this->display();
    }

    public function ud(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $this->display('useradd');
    }

    public function uadd(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $user=I('post.user');
        $password=I('post.password');
        $name=I('post.name');
        $sex=I('post.sex');
        $ly=I('post.ly');

        $data['per_user']=$user;
        $data['per_password']=md5($password);
        $data['per_tup']='/img/1jpg';
        $data['per_name']=$name;
        $data['per_sex']=$sex;
        $data['per_ty']='1';
        $data['per_ly']=$ly;
        $date=M('us')->data($data)->add();
        echo $date."添加成功！";
    }

}