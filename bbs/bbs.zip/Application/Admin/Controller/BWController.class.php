<?php
namespace Admin\Controller;
use Think\Controller;
class BWController extends Controller {
    public function w(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $date=M('wz')->select();
        $this->assign('date',$date);
        $this->display('bowen');
    }

    public function add(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $this->display('addbw');
    }
    public function doadd(){
        if(empty(session('per_id'))){
            $this->success('你没登录！', U('Log/log'),3);
            return;
        }
        $data['w_title']=$_GET['title'];
        $data['w_name']=$_GET['uname'];
        $data['time']=date('Y-m-d H:i:s');
        $data['jjie']=$_GET['jjie'];
        $data['text']=$_GET['text'];
        $date=M('wz')->data($data)->add();
        echo $date."添加成功！";
    }
}