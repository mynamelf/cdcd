<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $data=M('wz')->order('time desc')->limit(3)->select();
        $this->assign('data',$data);
        $this->display();
    }
}